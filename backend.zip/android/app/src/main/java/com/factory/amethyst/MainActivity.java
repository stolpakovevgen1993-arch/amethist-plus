package com.factory.amethyst;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
